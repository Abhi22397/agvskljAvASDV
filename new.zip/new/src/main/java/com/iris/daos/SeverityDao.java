package com.iris.daos;

import java.util.List;

import com.iris.models.Severity;

public interface SeverityDao {
	public List<Severity> getAllSeverity();
}
