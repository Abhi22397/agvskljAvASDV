package com.iris.service;

import java.util.List;

import com.iris.models.Severity;


public interface SeverityService {
	public List<Severity> getAllSeverity();
}
