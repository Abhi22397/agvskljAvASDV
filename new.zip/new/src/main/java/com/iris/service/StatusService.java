package com.iris.service;

import java.util.List;

import com.iris.models.BugStatus;

public interface StatusService {
	public List<BugStatus> getAllStatus();

}
